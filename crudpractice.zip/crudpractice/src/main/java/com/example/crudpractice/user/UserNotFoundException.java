package com.example.crudpractice.user;

public class UserNotFoundException extends Throwable {

    public UserNotFoundException(String s) {

    }
}

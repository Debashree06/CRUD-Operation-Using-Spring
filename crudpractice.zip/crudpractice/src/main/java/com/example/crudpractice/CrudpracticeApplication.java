package com.example.crudpractice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudpracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudpracticeApplication.class, args);
	}

}
